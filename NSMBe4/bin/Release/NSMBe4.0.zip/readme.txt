Treeki's New Super Mario Bros editor
Version 4.0 - released 13th April 2009
http://jul.rustedlogic.net/thread.php?id=244&page=15
----------
Thanks for downloading my new editor.
This editor will allow you to modify levels and the file system in New Super Mario Bros.
It supports editing objects and enemies/sprites, with more to come soon.

I don't have much else to say here, but here's a FAQ:

Q: How do I edit levels?
A: Open a ROM, pick a level and move/change stuff. If you can't figure that out you shouldn't be ROM hacking in the first place.

Q: Sprite data? What's this?
A: Some enemies/sprites have extra settings which are set in here - Koopa colours, for example. I don't have much documentation on this.

Q: How do I change the tileset or background in a level?
A: You can't - yet.

Q: How do I change entrances/exits?
A: Working on it!

Q: I made or moved a pipe, why won't it work?
A: See the above question.

Q: I made the level bigger, why won't it work?
A: Views aren't supported yet, because I don't know enough of the format. Therefore, for now you'll have to stick to the default level sizes.

Q: I can't run it! halp!
A: Check to make sure you have the .NET Framework 2.0 installed. (If you're on Vista, you should already have it.) If not, download this: http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=0856eacb-4362-4b0d-8edd-aab15c5e04f5

Q: Where do I get a NSMB ROM?
A: http://www.google.com


----------
Credits:

Treeki- Main coding and design
Blackhole89- Object parsing/rendering code
Mega-Moron- Failing at being a ROM hacker
Icons- http://www.pinvoke.com